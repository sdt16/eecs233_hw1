/**
 * 
 */

/**
 * @author Schuyler Thompson
 *
 */
interface Searchable {
public String find(int key);

}
